/*************************************************************************
  fichier contenant la forme du potentiel
  plusieurs types de potentiel : double ou simple créneau, triangulaire, trapèze et cloche à support compact
  ***********************************************************************/
#include <cmath>


long double V(long double x, long double a, long double a1, long double V0, int optionPotentiel)
{
/********* CRENEAU SIMPLE *********/
  if(optionPotentiel==0)
    {
    if(x<=0) return 0;
    if(x>0 && x<=a) return 0;
    if(x>a && x<=a1) return V0;
    if(x>a1) return 0;
    return 0;
    }

  /********* DOUBLE CRENEAU *********/
  if(optionPotentiel==1)
      {
      if (x<=0) return 0;
      if (x>0 && x<=a) return V0;
      if (x>a && x<=a1) return 0;
      if (x>a1 && x<=a1+a) return V0;
      if (x>a1+a) return 0;
      return 0;
      }

  /********* BARRIERE TRIANGULAIRE *********/
if(optionPotentiel==2)
  {
        if(x<a) return 0;
        if(x>a && x<=(a+a1)/2) return 2*V0/(a1-a)*(x-a);
        if(x>(a1+a)/2 && x<a1) return 2*V0/(a1-a)*(a1-x);
        if(x>=a1)return 0;
        return 0;
  }

/********* BARRIERE EN TRAPEZE *********/
if(optionPotentiel==3)
{
    if(x<a) return 0;
    if(x>=a && x<=a1) return -0.2*V0/(a1-a)*x+V0*(1.1+0.2*a/(a1-a));
    if(x>a1) return 0;
    return 0;
}
// NB : pour étudier spécifiquement l'effet d'une barrière trapèze, il faudrait introduire un autre paramètre : alpha, qui serait la pente de décroissansse.
// On pourrait alors observer l'effet de cette pente sur le coefficient de réfléxion


/********* BARRIERE EN CLOCHE A SUPPORT COMPACT (de classe C infini) *********/
if(optionPotentiel==4)
{
    if(x<=a) return 0;
    if(x>a && x<a1) return V0*exp(4/((a1-a)*(a1-a)))*exp(1/((x-a)*(x-a1)));
    if(x>=a1) return 0;
    return 0;
}

  else return(0);
  }
