/*****************************************************************************
  menu.cpp
  ensemble des procédures qui permet à l'utilisateur de choisir ce qu'il veut observer :
   -un profil simple (superposition de de la fonction psi avec le potentiel
   -tracer l'évolution du coefficient de réflexion en fonction de la masse
   -tracer l'évolution du coefficient de reflexion en fonction de l'énergie
   -tracer l'évolution du coefficient de reflexion en fonction de la largeur de la barrière dans le cas d'une barrière simple
   -tracer l'évolution du coefficient de reflexion en fonction du rapport distance sur largeur dans le cas d'une barrière double

  ****************************************************************************/


#include <iostream>
#include <fstream>
#include <cmath>
#include <cstdlib>
#include "Complex.h"     // pour utiliser les complexes
#include "potentiel.h"   // définition du potentiel
#include "exact.h"       // résultats exact pour le potentiel créneau simple
#include "algoCalc.h"    // algorithmes de calcul numérique

using namespace std;


#define N 10000

/**************************************************************
 CHOIX DU POTENTIEL
**************************************************************/
int choixPotentiel()
{
    int i;
    do{
        cout<<"choissiz un profil de potentil:" << endl;
    cout<<"0-> simple barrière" <<endl;
    cout<<"1-> double barrière" <<endl;
    cout<<"2-> Barrière en triangle"<<endl;
    cout<<"3-> Barrière en trapèze"<<endl;
    cout<<"4-> Barrière en cloche" <<endl;
    cin >>i;
    }while(i<0 || i>5);

    return i;
}

/**************************************************************
 CHOIX DU CALCUL A FAIRE
**************************************************************/
int menu(int optionPotentiel)
{
    int i;
    do{
        cout<<"Votre choix ?" <<endl;
        cout<<"1-> Un seul calcul ?"<<endl;
        cout<<"2-> faire varier la masse"<<endl;
        cout<<"3-> faire varier l'énergie"<<endl;
    if(optionPotentiel!=1)
    {
        cout<<"4->faire varier l'épaisseur de la barrière" <<endl;
    }
    else if(optionPotentiel==1)
    {
        cout<<"4->faire varier le rapport a/L (largeur barrière/distance entre les deux barrière"<<endl;

    }
    cin >>i;
    }while(i<1 || i>4);

    return i;
}

/*********************************************************************************************************
 premier choix : on fait un simple calcul du coeff de reflection et on trace l'évolution de la fonction d'onde
**********************************************************************************************************/
void choix1(int optionPotentiel)
{

        int option = 0;
        int enregistre = 0;
        long double r, V0, m, a, E, a1;
        long double hb = 1;
        long double e= 1;
        long double ang= 0.529177;
        Complex B(.1,.1) ;
        long double d = 0.01, del = 1e-7;// valeurs de précision
        Complex B2;

        do
        {
             cout<<"Entrer la valeur du potentiel V0 en eV:"<<endl;
             cin>>V0;
             V0=V0*e/27.21;
        }
        while (V0<0);

        do
        {
             cout<<"Entrer la valeur de l'energie E en eV:"<<endl;
             cin>>E;
             E=E*e/27.21;
        }
        while (E<0);



        do
        {
             cout<<"Entrer la valeur de la masse de la particule m en e-30 Kg:"<<endl;
             cin>>m;
           // m/=1e-30;
        }
        while (m<0);

        do
        {
             cout<<"Entrer la valeur de a  en Angstrom:"<<endl;
             cin>>a;
             a=a*ang;
             cout<<"Entrer la valeur de a1 en Angstrom:"<<endl;
             cin>>a1;
             a1=a1*ang;
        }
        while (a<0 || a1<a);

        if (optionPotentiel==0)
        {
        cout<<"Le coefficient de reflexion analytique est R= "<<1-T((a1-a), E, V0, hb, m)<<endl;
        }

        option = 0;
            cout << "méthode euler" <<endl;
            enregistre = 0; // NE PAS ENREGISTRER
        B2=steepestDescent(B, d, del, a, a1, E, V0, m,option,optionPotentiel);
        r =module(B2)*module(B2);
        if (r>1) r=1;
        cout<<"Le coefficient de reflexion numérique par euler est R= "<<r<<endl;

        B=Complex(0.1,0.1); // on réinitialise le B pour que les méthodes numérov et euler parte du même point et qu'on puisse alors comparer ces deux méthodes. (si on ne fait pas cela, la méthode numervo "triche"
            option = 1;
            cout << "methode numerov"<<endl;
        B2=steepestDescent(B, d, del, a, a1, E, V0, m,option,optionPotentiel);
        r =module(B2)*module(B2);
        if (r>1) r=1;
        cout<<"Le coefficient de reflexion numérique par numérov est R= "<<r<<endl;

         enregistre = 1; // ON ENREGISTRE
         resolution (B2, a, a1, E, V0, m,option,1,optionPotentiel);


}

/*********************************************************************************
 deuxième choix : on fait trace la valeur du coeff de reflection en fonction de la masse
*********************************************************************************/
void choix2(int optionPotentiel)
{
    long double r, V0, m0,mf, a, E, a1;
    long double hb = 1;
    long double e= 1;
    long double ang= 0.529177;
    long double d = 0.01, del = 1e-7, n=300;// valeurs de précision
 fstream f;
    f.open("variation_avec_la_masse.txt",ios::out);

    do
    {
         cout<<"Entrer la valeur de l'energie E en eV:"<<endl;
         cin>>E;
         E=E*e/27.21;
    }
    while (E<0);

    do
    {
         cout<<"Entrer la valeur du potentiel V0 en eV:"<<endl;
         cin>>V0;
         V0=V0*e/27.21;
    }
    while (V0<0);



    do
    {
         cout<<"Entrer la valeur de a en Angstrom:"<<endl;
         cin>>a;
         a=a*ang;
         cout<<"Entrer la valeur de a1 en Angstrom:"<<endl;
         cin>>a1;
         a1=a1*ang;
    }
    while (a<0 || a1<a);


    do
    {
         cout<<"Entrer la valeur de la masse initial m0 en e-30 Kg:"<<endl;
         cin>>m0;
       // m0/=1e-30;
    }
    while (m0<0);

    do
    {
         cout<<"Entrer la valeur de la masse final mf en e-30 Kg:"<<endl;
         cin>>mf;
       // mf/=1e-30;
    }
    while (mf<m0);


long double m=m0;
long double pas=(mf-m0)/n;
Complex B(.1,.1);

int k;
for(k=0; k<n; k++)
{
m+=pas;

cout << "calcul n°k:" <<k << "et m :"<<m<< endl;
        B=steepestDescent(B, d, del, a,a1, E, V0, m,1,optionPotentiel);  // On utilise le meilleur algo : numerov, et on réutilise l'ancien B !

        r = module(B)*module(B);
        if (r>1) r=1;
        if(optionPotentiel==0)
        {
            f<< m<<"   "<< r <<"   "<<(1-T((a1-a), E, V0, hb, m))<<endl;
        }
        else
        {
             f<< m<<"   "<< r <<endl;
        }
}

f.close(); /* fermeture du fichier */

}

/*************************************************************************
 troisième choix : on fait trace la valeur du coeff de reflection en fonction de la l'energie
****************************************************************************/
void choix3(int optionPotentiel)
{
    long double r, V0, m, a, E0,Ef, a1;
    long double hb = 1;
    long double e= 1;
    long double ang= 0.529177;
    long double d = 0.01, del = 1e-7, n=300;// valeurs de précision
 fstream f;
    f.open("variation_avec_energie.txt",ios::out);

    do
    {
         cout<<"Entrer la valeur de la masse m en e-30 kg:"<<endl;
         cin>>m;
        // m/=1e-30;
    }
    while (m<0);

    do
    {
         cout<<"Entrer la valeur du potentiel V0 en eV:"<<endl;
         cin>>V0;
         V0=V0*e/27.21;
    }
    while (V0<0);



    do
    {
         cout<<"Entrer la valeur de a en Angstrom:"<<endl;
         cin>>a;
         a=a*ang;
         cout<<"Entrer la valeur de a1 en Angstrom:"<<endl;
         cin>>a1;
         a1=a1*ang;
    }
    while (a<0 || a1<a);


    do
    {
         cout<<"Entrer la valeur de l'énérgie initial E0 en eV:"<<endl;
         cin>>E0;
           E0=E0*e/27.21;
    }
    while (E0<0);

    do
    {
         cout<<"Entrer la valeur de l'énergie final Ef en eV:"<<endl;
         cin>>Ef;
        Ef=Ef*e/27.21;
    }
    while (Ef<E0);


long double E=E0;
long double pas=(Ef-E0)/n;
Complex B(.1,.1);

int k;
for(k=0; k<n; k++)
{
E+=pas;

cout << "calcul n°k:" <<k << "et E :"<<E*27.21<< endl;
        B=steepestDescent(B, d, del, a,a1, E, V0,m,1,optionPotentiel);  // On utilise le meilleur algo : numerov, et on réutilise l'ancien B !

        r = module(B)*module(B);
        if (r>1) r=1;
        if(optionPotentiel==0)
        {
            f<< E*27.21<<"   "<< r <<"   "<<(1-T((a1-a), E, V0, hb, m))<<endl;
        }
        else
        {
             f<< E*27.21<<"   "<< r <<endl;
        }
}

f.close(); /* fermeture du fichier */

}

/**********************************************************************************************************************************
 Quatrième choix : on fait trace la valeur du coeff de reflection en fonction de la largeur a (cas du potentiel simple
************************************************************************************************************************************/
void choix4simple(int optionPotentiel)
{
    long double r, V0, m, a,E, a10,a1f;
    long double hb = 1;
    long double e= 1;
    long double ang= 0.529177;
    long double d = 0.01, del = 1e-7, n=300;// valeurs de précision
 fstream f;
    f.open("variation_longueur.txt",ios::out);

    do
    {
         cout<<"Entrer la valeur de la masse m en e-30 kg:"<<endl;
         cin>>m;
         //m/=1e-30;
    }
    while (m<0);

    do
    {
         cout<<"Entrer la valeur du potentiel V0 en eV:"<<endl;
         cin>>V0;
         V0=V0*e/27.21;
    }
    while (V0<0);

    do
    {
         cout<<"Entrer la valeur de l'énérgie E en eV:"<<endl;
         cin>>E;
           E=E*e/27.21;
    }
    while (E<0);

        a=0; // pour un potentiel simple, un seul paramètre suffit, mais pour réutiliser les mêmes programmes, j'ai artificielement créer un a ici
    do
    {
         cout<<"Entrer la largeur de la barrière initial a0 en Angstrom:"<<endl;
         cin>>a10;
         a10=a10*ang;
         cout<<"Entrer la largeur final de la barrière af en Angstrom:"<<endl;
         cin>>a1f;
         a1f=a1f*ang;
    }
    while (a10<0 || a1f<a10);

    long double a1=a10;
    long double pas=(a1f-a10)/n;
    Complex B(.1,.1);

    int k;
    for(k=0; k<n; k++)
    {
        a1+=pas;

        cout << "calcul n°" <<k << "  et a :"<<a1/ang<< endl;
        B=steepestDescent(B, d, del, a,a1, E, V0,m,1,optionPotentiel);  // On utilise le meilleur algo : numerov, et on réutilise l'ancien B !

        r = module(B)*module(B);
        if (r>1) r=1;

        if (optionPotentiel==0)
        {
            f<< a1/ang<<"   "<< r <<"   "<<(1-T((a1-a), E, V0, hb, m))<<endl;
        }
        else
        {
            f<< a1/ang<<"   "<< r <<endl;
        }
}

f.close(); /* fermeture du fichier */
}

/****************************************************************************************************
  4ème choix pour le potentiel Double : on fait varier a1/a : on fixe a et n fait varier a1
  ***************************************************************************************************/
void choix4Double(int optionPotentiel)
{
    long double r, V0, m, a,E, a10,a1f;
    long double hb = 1;
    long double e= 1;
    long double ang= 0.529177;
    long double d = 0.01, del = 1e-7, n=300;// valeurs de précision
 fstream f;
    f.open("variation_longueur.txt",ios::out);

    do
    {
         cout<<"Entrer la valeur de la masse m en e-30 kg:"<<endl;
         cin>>m;
         //m/=1e-30;
    }
    while (m<0);

    do
    {
         cout<<"Entrer la valeur du potentiel V0 en eV:"<<endl;
         cin>>V0;
         V0=V0*e/27.21;
    }
    while (V0<0);

    do
    {
         cout<<"Entrer la valeur de l'énérgie E en eV:"<<endl;
         cin>>E;
           E=E*e/27.21;
    }
    while (E<0);

        a=1*ang; // on fixe la taille des barrière et on fera varier la distance entre les deux barrières (L=a1-a)
    do
    {
         cout<<"Entrer le rapport (distance entre les deux barrières)/(largeur barrière) initial "<<endl;
         cin>>a10; // l'utilisateur rentre L/a 
         a10=(a10+1)*a; // on à L=a1-a donc a1=L+a=(L/a+1)a 
         cout<<"Entrer le rapport final af "<<endl;
         cin>>a1f;
         a1f=(1+a1f)*a;
    }
    while (a10<0);

long double a1=a10;
long double pas=(a1f-a10)/n;
Complex B(.1,.1);

int k;
for(k=0; k<n; k++)
{
a1+=pas;

cout << "calcul n°" <<k << "  et a :"<<a1/ang<< endl;
        B=steepestDescent(B, d, del, a,a1, E, V0,m,1,optionPotentiel);  // On utilise le meilleur algo : numerov, et on réutilise l'ancien B (car le B suivant ne devrait pas être trop long car les fonctions sont contunues) !

        r = module(B)*module(B);
        if (r>1) r=1;

            f<< (a1/a-1)<<"   "<< r <<endl;
}

f.close(); /* fermeture du fichier */
}

