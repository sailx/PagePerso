#ifndef EXACT_H
#define EXACT_H


long double T1(long double a, long double E, long double V0, long double hb, long double m);
long double T2(long double a, long double E, long double V0, long double hb, long double m);
long double T3(long double a, long double E, long double V0, long double hb, long double m);
long double T(long double a, long double E, long double V0, long double hb, long double m);

#endif // EXACT_H
