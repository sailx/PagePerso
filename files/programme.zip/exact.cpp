/****************************************************************************
  fichier exact.cpp
  calcul exact du coefficient de reflexion dans le cas d'un simple créneau
  **************************************************************************/


#include <cmath>
#include "potentiel.h"

/**** cas où E>V0 ****/
long double T1(long double a, long double E, long double V0, long double hb, long double m)
{
    long double k2a = sqrt((2*m*V0*a*a)/(hb*hb)*(1-E/V0));
    return (1/(1+((sinh(k2a)*sinh(k2a))/(4*E*(V0-E)/(V0*V0)))));
}

/**** cas où E=V0 ****/
long double T2(long double a, long double E, long double V0, long double hb, long double m)
{
    return (1/(1+(m*a*a*V0/(2*hb*hb))));
}

/***** cas où E<V0 ****/
long double T3(long double a, long double E, long double V0, long double hb, long double m)
{
    long double k3a = sqrt((2*m*V0*a*a)/(hb*hb)*(E/V0-1));
    return (1/(1+((sin(k3a)*sin(k3a))/(4*E*(E-V0)/(V0*V0)))));
}

/**** fonction global ****/
long double T(long double a, long double E, long double V0, long double hb, long double m)
{
    if (E<V0) return T1(a, E, V0, hb, m);
    else if (E==V0) return T2(a, E, V0, hb, m);
    else return T3( a, E, V0, hb, m);
}

