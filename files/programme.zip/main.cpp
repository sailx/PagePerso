/****************************************************************************
  fichier main.cpp
  **************************************************************************/


#include <iostream>
#include <fstream>
#include <cmath>
#include <cstdlib>
#include "Complex.h"     // pour utiliser les complexes
#include "potentiel.h"   // définition du potentiel
#include "exact.h"       // résultats exact pour le potentiel créneau simple
#include "algoCalc.h"    // algorithmes de calcul numérique
#include "menu.h"        // fonction menu

using namespace std;
#define N 10000



int main()
{

    int optionPotentiel=choixPotentiel();                           // On demande à l'utilisateur de choisir le potentiel qu'il veut utiliser
    int choix = menu(optionPotentiel);                              // On demande à l'utilisateur quel type de calcul il veut faire
    if (choix==1)                                                   // choix 1 : on fait 1 seul calcul
            {
            choix1(optionPotentiel);
            }
   else if (choix==2)                                               // choix 2 : on fait varier la masse
            {
            choix2(optionPotentiel);
            }
   else if (choix==3)                                               // choix 3 : on fait varier l'energie
            {
            choix3(optionPotentiel);
            }
   else if (choix==4 && optionPotentiel==0)                        // Choix 4 pour le créneau simple: on fait varier les longueurs
   {
       choix4simple(optionPotentiel);
   }
   else if (choix==4 && optionPotentiel==1)                        //Choix 4 pour le créneau double: on fait varier le rapport a/L
   {
       choix4Double(optionPotentiel);
   }
            else return 0;


return 0;

}

