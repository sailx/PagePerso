#ifndef POTENTIEL_H
#define POTENTIEL_H

long double V(long double x, long double a, long double a1, long double V0, int optionPotentiel);

#endif // POTENTIEL_H
