#ifndef ALGOCALC_H
#define ALGOCALC_H

/**** résolution pas à pas ****/
void nmrv (int n, long double h, long double q[] , Complex u[]);
void euler(int n, long double h, long double q[], Complex u[]);

/**** enregister dans un .txt ****/
void enregistrerPSI (const char* euler, long double x0, long double dx, Complex PSI[], int n, long double a,long double a1,long double V0, int optionPotentiel);

/**** algorithme de résolution ****/
Complex resolution (Complex B, long double a, long double a1, long double E, long double V0, long double m, int option, int enregistre, int optionPotentiel);

/**** Minimisation ****/
long double f (Complex B, long double a, long double a1, long double E, long double V0, long double m, int option, int optionPotentiel);
Complex calculGradient(Complex B, long double h, long double a, long double a1, long double E, long double V0, long double m, int option, int optionPotentiel);
Complex steepestDescent (Complex B, long double d, long double del, long double a, long double a1, long double E, long double V0, long double m, int option, int optionPotentiel);



#endif // ALGOCALC_H
