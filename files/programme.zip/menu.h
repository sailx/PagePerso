#ifndef MENU_H
#define MENU_H

int menu(int optionPotentiel);
void choix1(int optionPotentiel);
void choix2(int optionPotentiel);
void choix3(int optionPotentiel);
void choix4simple(int optionPotentiel);
void choix4Double(int optionPotentiel);
int choixPotentiel();

#endif // MENU_H
