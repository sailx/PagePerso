/****************************************************************************
  fichier algo.cpp
  les algorithmes de résolution numérique

  **************************************************************************/

#include <iostream>
#include <fstream>
#include <cmath>
#include <cstdlib>
#include "potentiel.h"
#include "exact.h"
#include "Complex.h"

using namespace std;


#define N 10000


/***** Résolution de l'équation de Schrödinger par l'algorithme Numérov : méthode d'approximation numérique à l'ordre 6 ****/
void nmrv (int n, long double h, long double q[] ,Complex u[])
{
        int i;
        long double g,c0,c1,c2;

        g = h*h/12;
        for (i = 1; i <n-1; ++i)
        {
                c0 = 1+g*q[i-1];
                c1 = 2-10*g*q[i];
                c2 = 1+g*q[i+1];
                u[i+1] = (c1*u[i]-c0*u[i-1])/c2;
        }
}

/**** Résolution de l'équation de Schrodinger par la méthode d'Euler : méthode d'approximation d'odre 4 ****/
void euler(int n, long double h, long double q[], Complex u[])
{
    int i;
    Complex z = (u[1] - u[0])/h;
    for(i=2; i<n; i++)
    {
        z-=h*q[i-1]*u[i-1];
        u[i]=u[i-1]+h*z;
    }
}

/*********************************************************************************
 Fonction qui enregistre l'évolution de la fonction d'onde sous la forme d'un tableau de 4 colonnes :
 - le potentiel (pour pouvoir superposer la courbe du potentiel avec les autres courbes)
 - la partie réelle de la fonction d'onde
 - la partie imaginaire
 - le module (densité de probabilité)
**********************************************************************************/

void enregistrerPSI (const char* euler, long double x0, long double dx, Complex PSI[], int n,long double a,long double a1,long double V0, int optionPotentiel)
{
        int i;
        long double x = x0;
        fstream f;
        f.open(euler,ios::out);


        for (i=0; i<n; i++)
        {
                f<<x<<"   "<< V(x,a,a1,V0,optionPotentiel)<<"   "<<PSI[i].getRe()<<"   "<<PSI[i].getIm()<<" "<< module(PSI[i])*module(PSI[i])<<endl;
                x = x+dx;
        }

        f.close();
}

/**** Fonction qui détermine l'évolution de la fonction d'onde à la traversée du potentiel et qui permet de retrouver sa forme initiale avant la traversée ****/
Complex resolution (Complex B, long double a, long double a1, long double E, long double V0, long double m, int option, int enregistre, int optionPotentiel)
{
        int i;
        Complex BN;                                             // BN sera la nouvelle valeur de B
        long double hb = 1;                                     // definition de hbarre
        long double x = 0.0;

        long double h = (a+a1)/(N-1);                           //définition

        long double q[N+2], qr[N+2];
        Complex PSI[N+2], PSIr[N+2];
        long double c = 2*m/(hb*hb);
        long double k = sqrt(c*E);
        long double kh = k*h;
        long double kh2 = kh*kh;

        for (i=1; i<N+1; i++)
        {
                q[i] = c*(E-V(x, a, a1, V0,optionPotentiel));
                x = x+h;

        }

        q[0] = c*E;
        q[N+1] = c*E;

// Initialisation du tableau de complexe PSI

        double re,im;
        re = (1-kh2/2)*(1+B.getRe())-B.getIm()*kh;
        //cout << "re "<< re << endl;
        im = (1-kh2/2)*B.getIm()-kh*(1-B.getRe());
        //cout << "im "<< im << endl;
        PSI[0]=Complex(re,im);

        PSI[1]=B+Complex(1,0);

        if(option==0)
        {
        euler(N+2, h, q, PSI);

        }
        else
        {
        nmrv(N+2, h, q, PSI);
       // if(enregistre==1)
       // enregistrerPSI("numerov.txt", -h, h, PSI, N+2,a,a1,V0,optionPotentiel);//'numerov' décrit l'évolution de la fonction d'onde à la traversée du potentiel

        }


        for (i=0; i<=N+1; i++)
        {
                qr[i] = q[N+1-i];
        }
        re=0;
        im=0;
        PSIr[1]=PSI[N];

        re=(1-kh2/2)*PSIr[1].getRe()-k*h*PSIr[1].getIm();
        im=(1-kh2/2)*PSIr[1].getIm()+k*h*PSIr[1].getRe();
        PSIr[0]=Complex(re,im);

        if(option==0)
        {
        euler(N+2, h, qr, PSIr);
        }
        else
        {
        nmrv(N+2, h, qr, PSIr);
        //if(enregistre==1)
        //enregistrerPSI("numerovr.txt", a+a1, -h, PSIr, N+1,a,a1,V0,optionPotentiel);//'eulerr.txt' décrit l'évolution de la fonction d'onde depuis la fin du potentiel jusqu'à son début
        }

        BN=PSIr[N]-Complex(1,0);

         if(enregistre==1)
         enregistrerPSI("numerov.txt", -h, h, PSI, N+2,a,a1,V0,optionPotentiel);//'numerov' décrit l'évolution de la fonction d'onde à la traversée du potentiel

        return(BN);
}

/**** Fonction f:C->R qui renvoie la différence entre les BN et B initial. C'est cette fonction qu'il va falloir minimiser ****/
long double f (Complex B, long double a, long double a1, long double E, long double V0, long double m,int option, int optionPotentiel)
{
        Complex BN;
        long double m2 = 0;
        BN=resolution(B, a, a1, E, V0, m,option,0,optionPotentiel);
        m2= module(B-BN)*module(B-BN);
        return(m2);

}

/**** Fonction qui calcule le gradient de f en tout point x  ****/
Complex calculGradient(Complex B, long double h, long double a, long double a1, long double E, long double V0, long double m, int option,int optionPotentiel)
{
        long double f0 = f(B, a, a1, E, V0, m, option,optionPotentiel);

        Complex C=B+Complex(h,0);
        long double re=(f(C,a,a1,E,V0,m,option,optionPotentiel)-f0)/h;

        long double im=(f(B+Complex(0,h),a,a1,E,V0,m,option,optionPotentiel)-f0)/h;

        Complex grad(re,im);
        return(grad);
}

/******************************************************************************************************************************************
Algorithme de minimisation : Fonction qui cherche par la méthode de descente directe (the steepest descent search) le minimun d'une fonction
à plusieurs variables ; ici on a une fonction à 2 variables Br=x[0] et Bi=x[1] qui correspond respectivement aux parties réelle et imaginaire
du coefficient de réflexion en amplitude de la fonction d'onde.
*******************************************************************************************************************************************/
Complex steepestDescent (Complex B, long double d, long double del, long double a, long double a1, long double E, long double V0, long double m,int option, int optionPotentiel)
{
        long double h = del;
        long double f0 = f(B, a, a1, E, V0, m, option,optionPotentiel);

        Complex gradf;
        long double deriv = 0;
        long double b;
        long double f1;

        Complex B2=B;

                gradf=calculGradient(B2, h, a,a1, E, V0, m, option,optionPotentiel);

                deriv = module(gradf);
             //   cout << deriv << endl;  // repère
                b = d/deriv;

                while (deriv > del)
                {
                        B2=B2-b*gradf;

                        h /= 1.1; // ce paramètre va influer sur la stabilité !!!!!!!!!!! => 1.2 = plus rapide mais moins stable, 1.1 => plus stalbe mais plus lent
                        gradf=calculGradient(B2,h, a,a1, E, V0, m, option,optionPotentiel);
                        deriv = module(gradf);

                        b = d/deriv;
                        f1 = f(B2, a,a1, E, V0, m,option,optionPotentiel);

                        if (f1 > f0) d /= 2;
                        else f0 = f1;
                 }
return(B2);
}

