/****************************************************************************
  fichier Complex.cpp
  Construction d'une classe Complex pour pouvoir manipuler les complexes
  **************************************************************************/
#include <iostream>
#include <cmath>
#include "Complex.h"

using namespace std;

/**** Constructeur ****/
Complex::Complex(long double re,long double im):m_re(re), m_im(im)
{
}
Complex::Complex(long double reel):m_re(reel), m_im(0)
{
}
Complex::Complex():m_re(0), m_im(0)
{
}

/**** Affichage ****/
void Complex::affiche(ostream& flux) const
{
    if(m_im == 0)
    {
        flux << m_re;
    }
    else
    {
        flux << m_re << "+i" << m_im ;
    }
}
/********************************************
  DEFINITION DES OPERATEURS USUELS
  ******************************************/
/**** Opérateur d'injection dans un flux ****/
ostream& operator<<(ostream& flux, Complex const& z)
{
    z.affiche(flux);
    return flux;
}

/**** Addition ****/
Complex& Complex::operator+=(const Complex &z)
{
    m_re +=z.m_re;
    m_im +=z.m_im;

    return *this;
}
Complex operator+(Complex const& a, Complex const& b)
{
    Complex copie(a);
    copie+=b;
    return copie;
}

/**** Soustraction ****/
Complex& Complex::operator-=(const Complex &z)
{
    m_re -=z.m_re;
    m_im -=z.m_im;

    return *this;
}
Complex operator-(Complex const& a, Complex const& b)
{
    Complex copie(a);
    copie-=b;
    return copie;
}

/**** Multiplication (par un autre complexe et par une réel ****/
Complex& Complex::operator*=(const Complex &z)
{
    m_re = m_re*z.m_re-m_im*z.m_im;
    m_im = m_re*z.m_im+m_im*z.m_re;

    return *this;
}
Complex operator*(Complex const& a, Complex const& b)
{
    Complex copie(a);
    copie*=b;
    return copie;
}
Complex& Complex::operator*=(const long double &b)
{
    m_re *= b;
    m_im *= b;

    return *this;
}
Complex operator*(long double const& b, Complex const& z)
{
    Complex copie(z);
    copie*=b;
    return copie;
}

Complex& Complex::operator/=(const long double &b)
{
    m_re /= b;
    m_im /= b;

    return *this;
}
Complex operator/(Complex const& z, long double const& b )
{
    Complex copie(z);
    copie/=b;
    return copie;
}

/**** Comparaisons ****/
bool Complex::estEgal(Complex const& b) const
{
    if (m_re == b.m_re && m_im == b.m_im)
        return true;
    else
        return false;
}
bool operator==(Complex const& a, Complex const& b)
{
    return a.estEgal(b);
}
bool operator!=(Complex const& a, Complex const& b)
{
    if(a==b)
        return(false);
    else
        return(true);
}

/**** Conjugaison ****/
void Complex::conjugue()
{
    m_im = -m_im;
}

/**** Accesseurs ****/
long double Complex::getRe() const
{
    return m_re;
}
long double Complex::getIm() const
{
    return m_im;
}

void Complex::setIm(long double im)
{
    m_im=im;
}


/**** Module ****/
long double module(Complex const a)
{
    long double re=a.getRe();
    long double im=a.getIm();
    long double M=sqrt(re*re+im*im);
    return(M);
}

/**** exponentielle complexe ****/
Complex expi(long double const x)
{
    long double re=cos(x);
    long double im=sin(x);
    Complex z=Complex(re,im);
    return (z);
}
