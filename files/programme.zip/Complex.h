#ifndef DEF_COMPLEXE
#define DEF_COMPLEXE

#include <iostream>

class Complex
{
public:

    //Constructeurs
    Complex(long double re, long double im);
    Complex(long double re);
    Complex();

    //Affichage
    void affiche(std::ostream &flux) const;

    //Opérateurs arithmétiques
    Complex& operator*=(Complex const& autre);
    Complex& operator+=(Complex const& autre);
    Complex& operator-=(const Complex &z);
    Complex& operator/=(long double const& b);
    Complex& operator*=(long double const& b);

    //Méthodes de comparaison
    bool estEgal(Complex const& b) const;

    //Accesseurs
    long double getIm() const;
    long double getRe() const;
    void setIm(long double im);
    void setRe(long double re);


private:
    long double m_re;      //partie réel
    long double m_im;      //partie imaginaire

    // Conjugue le complexe
        void conjugue();

};

// Opérateur arithmétique
Complex operator*(Complex const& a, Complex const& b);
Complex operator*(long double const& b, Complex const& z);
Complex operator+(Complex const& a, Complex const& b);
Complex operator-(Complex const& a, Complex const& b);
Complex operator/( Complex const& z,long double const& b);

//Opérateur d'injection dans un flux
std::ostream& operator<<(std::ostream& flux, Complex const& z);

//Operateurs de comparaisons
bool operator==(Complex const& a, Complex const& b);
bool operator!=(Complex const& a, Complex const& b);

//Module
long double module(Complex const a);
// expontentiel complexe
Complex expi(long double const x);






#endif
